import re
from core.executor import run_command
from core.voice_simulator import simulate_voice_input

def parse_line(line):
    if line.startswith("speak "):
        text = re.findall(r'"(.*?)"', line)
        if text:
            run_command("speak", text[0])
    elif line.startswith("do "):
        action = re.findall(r'"(.*?)"', line)
        if action:
            run_command("do", f"open {action[0]}")  # basic, bisa dikembangkan nanti

def run_jla(file_path):
    with open(file_path, "r") as f:
        lines = f.readlines()
        for line in lines:
            line = line.strip()
            if line.startswith("speak ") or line.startswith("do "):
                parse_line(line)

if __name__ == "__main__":
    print("🔵 JΛ-01 Interpreter v0.1 Started")
    run_jla("samples/hello.jla")

    while True:
        voice = input("🎤 Simulasi suara (ex: hello juliet): ")
        simulate_voice_input(voice)
