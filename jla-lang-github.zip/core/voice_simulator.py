from core.executor import run_command

def simulate_voice_input(user_input):
    if user_input.lower() == "hello juliet":
        run_command("speak", "Hello, Castiel. How may I assist you?")
