def speak(text):
    print(f"[JΛ-01] 🔊 {text}")

def listen():
    print("[JΛ-01] 🎧 Listening... (simulasi, input suara belum diaktifkan)")
