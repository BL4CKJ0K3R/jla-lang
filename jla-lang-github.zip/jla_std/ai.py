def suggest(text):
    print(f"[JΛ-01] 💡 Suggestion: {text}")

def respond(query):
    # Simulasi respons AI
    response = f"I'm not fully trained yet, but I think '{query}' is interesting!"
    print(f"[JΛ-01] 🤖 {response}")

def learn_new_command(description):
    print(f"[JΛ-01] 🧠 Learning new behavior: '{description}' (simulasi)")
