import webbrowser
import os

def open_url(link):
    print(f"[JΛ-01] 🌐 Opening: {link}")
    try:
        webbrowser.open(link)
    except Exception as e:
        print(f"[JΛ-01] ❌ Failed to open URL: {e}")

def shutdown():
    print("[JΛ-01] 🔌 System shutdown simulated")
